import "./App.css";
import Board from "./component/Board";

function App() {
  return (
    <div className="App">
      <Board />
    </div>
  );
}

export default App;
