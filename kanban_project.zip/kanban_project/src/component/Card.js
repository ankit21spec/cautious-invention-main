// Card.js
import React, { useState } from "react";
import { useDrag } from "react-dnd";
import Modal from "react-modal";
import "./Card.css";

const Card = ({ task, index, moveCard, updateTask }) => {
  const [modalIsOpen, setModalIsOpen] = useState(false);
  const [title, setTitle] = useState(task.title);
  const [description, setDescription] = useState(task.description);

  const openModal = () => {
    setModalIsOpen(true);
  };

  const closeModal = () => {
    setModalIsOpen(false);
  };

  const handleSave = () => {
    updateTask(task.id, title, description);
    closeModal();
  };

  const [{ isDragging }, drag] = useDrag({
    type: "CARD",
    item: { id: task.id, index },
    collect: (monitor) => ({
      isDragging: monitor.isDragging(),
    }),
  });

  return (
    <div
      ref={drag}
      className="card"
      onClick={openModal}
      style={{ opacity: isDragging ? 0.5 : 1 }}
    >
      <h4>{task.title}</h4>
      <p>{task.description}</p>
      <p>Status: {task.status}</p>
      <Modal isOpen={modalIsOpen} onRequestClose={closeModal}>
        <h2>Edit Task</h2>
        <label>
          Title:
          <input
            type="text"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
          />
        </label>
        <label>
          Description:
          <textarea
            value={description}
            onChange={(e) => setDescription(e.target.value)}
          />
        </label>
        <button onClick={handleSave}>Save</button>
        <button onClick={closeModal}>Close</button>
      </Modal>
    </div>
  );
};

export default Card;
