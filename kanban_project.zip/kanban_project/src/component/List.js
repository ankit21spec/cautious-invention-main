// List.js
import React, { useState } from 'react';
import { useDrop } from 'react-dnd';
import Card from './Card';
import './List.css';

const List = ({ list, addTask, moveCard, updateTask }) => {
  const [taskTitle, setTaskTitle] = useState('');
  const [error, setError] = useState('');

  const handleAddTask = () => {
    if (taskTitle.trim() === '') {
      setError('Task title cannot be empty');
      return;
    }
    const newTask = { id: Date.now(), title: taskTitle, description: '', status: list.title };
    addTask(list.id, newTask);
    setTaskTitle('');
    setError('');
  };

  const [, drop] = useDrop({
    accept: 'CARD',
    drop: (item, monitor) => {
      moveCard(item.id, list.id, list.title);
    },
  });

  return (
    <div ref={drop} className="list">
      <h3>{list.title}</h3>
      <div className="cards">
        {list.tasks.map((task, index) => (
          <Card key={task.id} task={task} index={index} moveCard={moveCard} updateTask={updateTask} />
        ))}
      </div>
      {list.title === "To Do" && (
        <>
          <input
            type="text"
            value={taskTitle}
            onChange={(e) => setTaskTitle(e.target.value)}
            placeholder="Add a task"
          />
          <button onClick={handleAddTask}>Add Task</button>
        </>
      )}
      {error && <p className="error">{error}</p>}
    </div>
  );
};

export default List;
